var http=require("http");
var fs=require("fs");
var path=require("path");
var port=3000;
var folder=path.join(__dirname,"..");
var types={".html":"text/html",".css":"text/css",".js":"text/javascript",".json":"application/json",".jpg":"image/jpeg",".jpeg":"image/jpeg",".png":"image/png"};
var server=http.createServer(function(request,response){
var file=request.url=="/"?"index.html":request.url.substring(1);
file=file.split("?")[0];
var filePath=path.join(folder,file);
if(!filePath.startsWith(folder)){response.writeHead(403);response.end("Forbidden");return;}
fs.readFile(filePath,function(error,data){
if(error){response.writeHead(404,{"Content-Type":"text/plain"});response.end("Page not found");return;}
var ext=path.extname(filePath).toLowerCase();
response.writeHead(200,{"Content-Type":types[ext]||"text/plain"});
response.end(data);
});
});
server.listen(port,function(){console.log("Saffron Skies server started at http://localhost:"+port);});
