SAFFRON SKIES - SMART TRAVEL PLANNER

1. Open the NodeJS folder in Command Prompt.
2. Run: node app.js
3. Open: http://localhost:3000

The six destinations are stored in destinations.json.
JavaScript reads the JSON and creates destination cards dynamically.
Images are connected through the image field in JSON. Internet is needed for the Unsplash images used for the six destination cards.

Main features:
- Home page
- Six destination cards from JSON
- Search and category filter
- Trip planner
- Budget calculator
- Packing checklist
- Login demo using browser storage
- Node.js server
- XML destination data for XML demonstration
